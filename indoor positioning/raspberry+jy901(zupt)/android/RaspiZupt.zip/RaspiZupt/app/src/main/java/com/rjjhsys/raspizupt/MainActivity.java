package com.rjjhsys.raspizupt;
import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.widget.TextView;
import Jama.Matrix;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.concurrent.Semaphore;

public class MainActivity extends Activity
{
    StringBuilder show = new StringBuilder();
    double[] getPoint = new double[3];
    boolean flag = true;
    double g = 9.8;
    double pitch;
    double roll;
    double yaw;
    double preTime=0;
    double dt;
    private DrawView drawView1;
    private Handler handler;
    Matrix gyroMatr = new Matrix(3,1);
    Matrix accMatr = new Matrix(3,1);
    Matrix accN = new Matrix(3,1);//Convert the data into state coordinate system.将得到的数据转化为状态坐标系下
    Matrix accS = new Matrix(3,1);//Raw Acceleration Data Matrix.原始加速度数据矩阵
    Matrix velN = new Matrix(3,1);//Save speed data.进行速度数据的保存
    Matrix posN = new Matrix(3,1);//Save the date of location.进行位置的数据保存
    MatrixOperator matrixOperator = new MatrixOperator();
    MyKalmanFilter myKalmanFilter = new MyKalmanFilter();
    //Read the file.进行文件的读
    /*
    String sdPath = Environment.getExternalStorageDirectory().getAbsolutePath();
    String FILE_NAME2 = "/Liuwu/data.txt";
    String fpath = sdPath + FILE_NAME2;
    File file = new File(fpath);
    String wfile = sdPath+"/Liuwu/point.txt";
    File fileWrite = new File(wfile);
    BufferedReader bufferedReader;
    public Semaphore semaphore = new Semaphore(1);
    */
    //    File file = new File("C:\\Users\\gongyan\\Desktop\\data.txt");
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        drawView1 = (DrawView) this.findViewById(R.id.myView);
        /*
        try {
             bufferedReader = new BufferedReader(new FileReader(file));//Initialize the read flow of file 初始化文件读取流
        } catch (IOException e) {
            e.printStackTrace();
        }
        */
        //Read the file.进行文件的读取
        handler = new Handler(){
            public void handleMessage(Message msg){
                drawView1.setXY(getPoint[0],getPoint[1]);
//                String p = String.valueOf(getPoint[0])+" "+String.valueOf(getPoint[1]);
//                try {
//                    BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(wfile,true));
//                    bufferedWriter.write(p+"\n");
//                    bufferedWriter.flush();
//                    bufferedWriter.close();
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
                System.out.println("main85：X:"+getPoint[0]+" "+"Y:"+getPoint[1]);
            }
        };
        new Thread() {//Create the thread.创建线程
            public void run() {
                try {
//                  ServerSocket serverSocket = new ServerSocket(5678);
                    DatagramSocket socket = new DatagramSocket(5678);
                    byte[] recvBuf = new byte[1024];
                    DatagramPacket recvPacket
                            = new DatagramPacket(recvBuf , recvBuf.length);
                    while (true) {
                                socket.receive(recvPacket);
                        String show = new String(recvPacket.getData() , 0 , recvPacket.getLength());
//                  stem.out.println("\n");
                        
                        //data processing.下面一段进行数据处理

                        double[] data=Util.parseData(show);//The obtained data.time, acceleration triaxial and gyroscope.获得的数据，前面是时间，加速度三轴，陀螺仪
                        if(flag){
                            //The first set of data is updated with the matrix and data initialization.第一组数据进行矩阵的更新，数据的初始化
                            init(data);
                            flag = false;
                        }
                        else {
                            //Data upload and image processing.进行数据的上传和进行图像的处理
                            updateAngDist(data);
                        }
                    }
                }
                catch (Exception e){
                    System.out.println("服务器异常："+e.getMessage());
                    e.printStackTrace();
                }
            }
        }.start();
    }
    //Read the file data.读取文件数据
       
    private void updateAngDist(double[] data) {
        dt = data[0]/1000000 - preTime;//Negative timestamps.时间戳是负的
        preTime = data[0]/1000000;
//      dt = (preTime - data[0])/1000000;//Negative timestamps.时间戳是负的
//        System.out.println("时间戳是"+dt);
        //Acceleration matrix assignmen.t加速度矩阵赋值
        accMatr.set(0, 0, data[1]);
        accMatr.set(1, 0, data[2]);
        accMatr.set(2, 0, data[3]);
        //Gyro Matrix Assignment.陀螺仪矩阵赋值
        gyroMatr.set(0, 0, data[4]);
        gyroMatr.set(1, 0, data[5]);
        gyroMatr.set(2, 0, data[6]);
        //Calculate the acceleration instead in order to get the angle value directly instead of the differential value.
		//直接得到角度值而不是微分值，应该改为把加速度计算出
        //The distance from a certain moment should be obtained from above and the angle corresponding to that moment.
		//通过上边应该得到某一时刻的距离以及该时刻对应的角度
        getPoint = myKalmanFilter.update(dt,accMatr,gyroMatr);
//      System.out.println("getPoint"+myKalmanFilter.newPos.get(0,0)+"****"+myKalmanFilter.newPos.get(1,0));
        Message message = new Message();
        handler.sendMessage(message);        //Drawing by the resulting coordinate values通过得到的坐标值进行绘画
        //-----------------------------------------------------------
        //Update the image.接下来进行图像的更新
    }
    public void init(double[] data){
        preTime = data[0]/1000000;
        //Get the initial direction matrix and initialize the yaw angle.得到初始方向矩阵以及初始化yaw角
        pitch = -Math.asin(data[1]/g);
        roll = Math.atan(data[2]/data[3]);
        yaw = 0;
        MyKalmanFilter.C = matrixOperator.getOrientationMatrix(pitch,roll,yaw);
        MyKalmanFilter.C_prev = MyKalmanFilter.C;//Value transfer.进行值传递
        accS.set(0,0,data[1]);
        accS.set(1,0,data[2]);
        accS.set(2,0,data[3]);
        accN = MyKalmanFilter.C.times(accS);//Get coordinates in navigation coordinates.得到导航坐标下的坐标
        myKalmanFilter.preAcc.set(0,0,accN.get(0,0));
        myKalmanFilter.preAcc.set(1,0,accN.get(1,0));
        myKalmanFilter.preAcc.set(2,0,accN.get(2,0));
        velN.set(0,0,0);
        velN.set(1,0,0);
        velN.set(2,0,0);
        posN.set(0,0,0);
        posN.set(1,0,0);
        posN.set(2,0,0);
    }
    public Matrix getZero(Matrix a){
        int row = a.getRowDimension();
        int co = a.getColumnDimension();
        for(int i =0;i<row;i++){
            for(int j = 0;j<co;j++){
                a.set(i,j,0);
            }
        }
        return a;
    }
}